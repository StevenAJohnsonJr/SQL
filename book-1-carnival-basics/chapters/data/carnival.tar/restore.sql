--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1
-- Dumped by pg_dump version 15.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE carnival;
--
-- Name: carnival; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE carnival WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


ALTER DATABASE carnival OWNER TO postgres;

\connect carnival

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: carrepairtypelogs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.carrepairtypelogs (
    car_repair_type_log_id integer NOT NULL,
    date_occured timestamp with time zone,
    vehicle_id integer,
    repair_type_id integer
);


ALTER TABLE public.carrepairtypelogs OWNER TO postgres;

--
-- Name: carrepairtypelogs_car_repair_type_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.carrepairtypelogs ALTER COLUMN car_repair_type_log_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.carrepairtypelogs_car_repair_type_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customers (
    customer_id integer NOT NULL,
    first_name character varying(50),
    last_name character varying(50),
    email character varying(50),
    phone character varying(50),
    street character varying(50),
    city character varying(50),
    state character varying(50),
    zipcode character varying(50),
    company_name character varying(50),
    phone_number character varying(50)
);


ALTER TABLE public.customers OWNER TO postgres;

--
-- Name: customers_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.customers ALTER COLUMN customer_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.customers_customer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dealershipemployees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dealershipemployees (
    dealership_employee_id integer NOT NULL,
    dealership_id integer,
    employee_id integer
);


ALTER TABLE public.dealershipemployees OWNER TO postgres;

--
-- Name: dealershipemployees_dealership_employee_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.dealershipemployees ALTER COLUMN dealership_employee_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.dealershipemployees_dealership_employee_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dealerships; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dealerships (
    dealership_id integer NOT NULL,
    business_name character varying(50),
    phone character varying(50),
    city character varying(50),
    state character varying(50),
    website character varying(1000),
    tax_id character varying(50)
);


ALTER TABLE public.dealerships OWNER TO postgres;

--
-- Name: dealerships_dealership_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.dealerships ALTER COLUMN dealership_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.dealerships_dealership_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: employees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employees (
    employee_id integer NOT NULL,
    first_name character varying(50),
    last_name character varying(50),
    email_address character varying(50),
    phone character varying(50),
    employee_type_id integer
);


ALTER TABLE public.employees OWNER TO postgres;

--
-- Name: employees_employee_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.employees ALTER COLUMN employee_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.employees_employee_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: employeetypes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employeetypes (
    employee_type_id integer NOT NULL,
    employee_type_name character varying(20)
);


ALTER TABLE public.employeetypes OWNER TO postgres;

--
-- Name: employeetypes_employee_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.employeetypes ALTER COLUMN employee_type_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.employeetypes_employee_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: oilchangelogs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oilchangelogs (
    oil_change_log_id integer NOT NULL,
    date_occured timestamp with time zone,
    vehicle_id integer
);


ALTER TABLE public.oilchangelogs OWNER TO postgres;

--
-- Name: oilchangelogs_oil_change_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.oilchangelogs ALTER COLUMN oil_change_log_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.oilchangelogs_oil_change_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: repairtypes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.repairtypes (
    repair_type_id integer NOT NULL,
    repair_type_name character varying(50)
);


ALTER TABLE public.repairtypes OWNER TO postgres;

--
-- Name: repairtypes_repair_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.repairtypes ALTER COLUMN repair_type_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.repairtypes_repair_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: sales; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales (
    sale_id integer NOT NULL,
    sales_type_id integer,
    vehicle_id integer,
    employee_id integer,
    customer_id integer,
    dealership_id integer,
    price numeric(8,2),
    deposit integer,
    purchase_date date,
    pickup_date date,
    invoice_number character varying(50),
    payment_method character varying(50),
    sale_returned boolean
);


ALTER TABLE public.sales OWNER TO postgres;

--
-- Name: sales_sale_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.sales ALTER COLUMN sale_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.sales_sale_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: salestypes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.salestypes (
    sales_type_id integer NOT NULL,
    sales_type_name character varying(8)
);


ALTER TABLE public.salestypes OWNER TO postgres;

--
-- Name: salestypes_sales_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.salestypes ALTER COLUMN sales_type_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.salestypes_sales_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: vehicles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vehicles (
    vehicle_id integer NOT NULL,
    vin character varying(50),
    engine_type character varying(2),
    vehicle_type_id integer,
    exterior_color character varying(50),
    interior_color character varying(50),
    floor_price integer,
    msr_price integer,
    miles_count integer,
    year_of_car integer,
    is_sold boolean,
    is_new boolean,
    dealership_location_id integer
);


ALTER TABLE public.vehicles OWNER TO postgres;

--
-- Name: vehicles_vehicle_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.vehicles ALTER COLUMN vehicle_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.vehicles_vehicle_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: vehicletypes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vehicletypes (
    vehicle_type_id integer NOT NULL,
    body_type character varying(5),
    make character varying(50),
    model character varying(50)
);


ALTER TABLE public.vehicletypes OWNER TO postgres;

--
-- Name: vehicletypes_vehicle_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.vehicletypes ALTER COLUMN vehicle_type_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.vehicletypes_vehicle_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: carrepairtypelogs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.carrepairtypelogs (car_repair_type_log_id, date_occured, vehicle_id, repair_type_id) FROM stdin;
\.
COPY public.carrepairtypelogs (car_repair_type_log_id, date_occured, vehicle_id, repair_type_id) FROM '$$PATH$$/3418.dat';

--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customers (customer_id, first_name, last_name, email, phone, street, city, state, zipcode, company_name, phone_number) FROM stdin;
\.
COPY public.customers (customer_id, first_name, last_name, email, phone, street, city, state, zipcode, company_name, phone_number) FROM '$$PATH$$/3408.dat';

--
-- Data for Name: dealershipemployees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dealershipemployees (dealership_employee_id, dealership_id, employee_id) FROM stdin;
\.
COPY public.dealershipemployees (dealership_employee_id, dealership_id, employee_id) FROM '$$PATH$$/3428.dat';

--
-- Data for Name: dealerships; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dealerships (dealership_id, business_name, phone, city, state, website, tax_id) FROM stdin;
\.
COPY public.dealerships (dealership_id, business_name, phone, city, state, website, tax_id) FROM '$$PATH$$/3406.dat';

--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employees (employee_id, first_name, last_name, email_address, phone, employee_type_id) FROM stdin;
\.
COPY public.employees (employee_id, first_name, last_name, email_address, phone, employee_type_id) FROM '$$PATH$$/3424.dat';

--
-- Data for Name: employeetypes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employeetypes (employee_type_id, employee_type_name) FROM stdin;
\.
COPY public.employeetypes (employee_type_id, employee_type_name) FROM '$$PATH$$/3420.dat';

--
-- Data for Name: oilchangelogs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oilchangelogs (oil_change_log_id, date_occured, vehicle_id) FROM stdin;
\.
COPY public.oilchangelogs (oil_change_log_id, date_occured, vehicle_id) FROM '$$PATH$$/3414.dat';

--
-- Data for Name: repairtypes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.repairtypes (repair_type_id, repair_type_name) FROM stdin;
\.
COPY public.repairtypes (repair_type_id, repair_type_name) FROM '$$PATH$$/3416.dat';

--
-- Data for Name: sales; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales (sale_id, sales_type_id, vehicle_id, employee_id, customer_id, dealership_id, price, deposit, purchase_date, pickup_date, invoice_number, payment_method, sale_returned) FROM stdin;
\.
COPY public.sales (sale_id, sales_type_id, vehicle_id, employee_id, customer_id, dealership_id, price, deposit, purchase_date, pickup_date, invoice_number, payment_method, sale_returned) FROM '$$PATH$$/3426.dat';

--
-- Data for Name: salestypes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.salestypes (sales_type_id, sales_type_name) FROM stdin;
\.
COPY public.salestypes (sales_type_id, sales_type_name) FROM '$$PATH$$/3410.dat';

--
-- Data for Name: vehicles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vehicles (vehicle_id, vin, engine_type, vehicle_type_id, exterior_color, interior_color, floor_price, msr_price, miles_count, year_of_car, is_sold, is_new, dealership_location_id) FROM stdin;
\.
COPY public.vehicles (vehicle_id, vin, engine_type, vehicle_type_id, exterior_color, interior_color, floor_price, msr_price, miles_count, year_of_car, is_sold, is_new, dealership_location_id) FROM '$$PATH$$/3422.dat';

--
-- Data for Name: vehicletypes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vehicletypes (vehicle_type_id, body_type, make, model) FROM stdin;
\.
COPY public.vehicletypes (vehicle_type_id, body_type, make, model) FROM '$$PATH$$/3412.dat';

--
-- Name: carrepairtypelogs_car_repair_type_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.carrepairtypelogs_car_repair_type_log_id_seq', 1, false);


--
-- Name: customers_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customers_customer_id_seq', 1100, true);


--
-- Name: dealershipemployees_dealership_employee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dealershipemployees_dealership_employee_id_seq', 1028, true);


--
-- Name: dealerships_dealership_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dealerships_dealership_id_seq', 50, true);


--
-- Name: employees_employee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employees_employee_id_seq', 1000, true);


--
-- Name: employeetypes_employee_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employeetypes_employee_type_id_seq', 7, true);


--
-- Name: oilchangelogs_oil_change_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.oilchangelogs_oil_change_log_id_seq', 1, false);


--
-- Name: repairtypes_repair_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.repairtypes_repair_type_id_seq', 20, true);


--
-- Name: sales_sale_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sales_sale_id_seq', 5000, true);


--
-- Name: salestypes_sales_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.salestypes_sales_type_id_seq', 2, true);


--
-- Name: vehicles_vehicle_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.vehicles_vehicle_id_seq', 10000, true);


--
-- Name: vehicletypes_vehicle_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.vehicletypes_vehicle_type_id_seq', 30, true);


--
-- Name: carrepairtypelogs carrepairtypelogs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carrepairtypelogs
    ADD CONSTRAINT carrepairtypelogs_pkey PRIMARY KEY (car_repair_type_log_id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (customer_id);


--
-- Name: dealershipemployees dealershipemployees_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dealershipemployees
    ADD CONSTRAINT dealershipemployees_pkey PRIMARY KEY (dealership_employee_id);


--
-- Name: dealerships dealerships_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dealerships
    ADD CONSTRAINT dealerships_pkey PRIMARY KEY (dealership_id);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (employee_id);


--
-- Name: employeetypes employeetypes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employeetypes
    ADD CONSTRAINT employeetypes_pkey PRIMARY KEY (employee_type_id);


--
-- Name: oilchangelogs oilchangelogs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oilchangelogs
    ADD CONSTRAINT oilchangelogs_pkey PRIMARY KEY (oil_change_log_id);


--
-- Name: repairtypes repairtypes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.repairtypes
    ADD CONSTRAINT repairtypes_pkey PRIMARY KEY (repair_type_id);


--
-- Name: sales sales_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_pkey PRIMARY KEY (sale_id);


--
-- Name: salestypes salestypes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salestypes
    ADD CONSTRAINT salestypes_pkey PRIMARY KEY (sales_type_id);


--
-- Name: vehicles vehicles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_pkey PRIMARY KEY (vehicle_id);


--
-- Name: vehicletypes vehicletypes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vehicletypes
    ADD CONSTRAINT vehicletypes_pkey PRIMARY KEY (vehicle_type_id);


--
-- Name: carrepairtypelogs carrepairtypelogs_repair_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carrepairtypelogs
    ADD CONSTRAINT carrepairtypelogs_repair_type_id_fkey FOREIGN KEY (repair_type_id) REFERENCES public.repairtypes(repair_type_id);


--
-- Name: dealershipemployees dealershipemployees_dealership_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dealershipemployees
    ADD CONSTRAINT dealershipemployees_dealership_id_fkey FOREIGN KEY (dealership_id) REFERENCES public.dealerships(dealership_id);


--
-- Name: dealershipemployees dealershipemployees_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dealershipemployees
    ADD CONSTRAINT dealershipemployees_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(employee_id);


--
-- Name: employees employees_employee_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_employee_type_id_fkey FOREIGN KEY (employee_type_id) REFERENCES public.employeetypes(employee_type_id);


--
-- Name: sales sales_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(customer_id);


--
-- Name: sales sales_dealership_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_dealership_id_fkey FOREIGN KEY (dealership_id) REFERENCES public.dealerships(dealership_id);


--
-- Name: sales sales_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(employee_id);


--
-- Name: sales sales_sales_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_sales_type_id_fkey FOREIGN KEY (sales_type_id) REFERENCES public.salestypes(sales_type_id);


--
-- Name: sales sales_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(vehicle_id);


--
-- Name: vehicles vehicles_dealership_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_dealership_location_id_fkey FOREIGN KEY (dealership_location_id) REFERENCES public.dealerships(dealership_id);


--
-- Name: vehicles vehicles_vehicle_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_vehicle_type_id_fkey FOREIGN KEY (vehicle_type_id) REFERENCES public.vehicletypes(vehicle_type_id);


--
-- PostgreSQL database dump complete
--

